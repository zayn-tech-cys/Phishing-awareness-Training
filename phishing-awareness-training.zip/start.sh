#!/bin/sh
# Opens the phishing awareness training module in your default browser.
#
# The module is a single self-contained HTML file and needs no internet
# connection, no Python and no installation.

set -e
DIR=$(cd "$(dirname "$0")" && pwd)

if command -v open >/dev/null 2>&1; then
    open "$DIR/index.html"
elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$DIR/index.html"
else
    echo "Could not find a browser opener. Open this file manually:"
    echo "  $DIR/index.html"
fi
