# Phishing Awareness Training — Facilitator Guide

A self-contained, offline training module on recognising and resisting phishing.

## What this is

A single-file interactive module (`index.html`) covering how phishing works, how
to spot it, what social engineering tactics are used, what to do if you have
already clicked, and how to report. There are 16 auto-marked quiz questions and
four hands-on "inspect this message" exercises, plus a printable one-page cheat
sheet and a completion certificate.

**No installation, no internet, no tracking, no dependencies.** Open
`index.html` in any modern browser and it runs. It works from a USB stick in a
training room with no network.

Everything works offline. Verified: the page loads no external resources at all.

## Getting started

Double-click `index.html`, or:

| Platform | Command |
| --- | --- |
| Windows | `start.bat` |
| macOS / Linux | `./start.sh` |
| Any | Just double-click `index.html` |

To present it full screen, press **F11**. Navigate with the arrow keys, the
buttons at the bottom, or the sidebar.

Progress and quiz answers are saved in the browser's local storage, so people
can stop and resume. Clearing site data resets it.

## Learning objectives

By the end, participants should be able to:

1. **Recognise** a phishing message within a few seconds.
2. **Explain** the social engineering tactics attackers rely on.
3. **Inspect** a link, domain or QR code before trusting it.
4. **Respond** correctly and quickly after a mistake.
5. **Report** a suspicious message without fear of blame.

## Suggested run of show

Total runtime is roughly **35–45 minutes** for a live session, or about 25
minutes for self-paced completion.

| Section | Topic | Minutes | Notes |
| --- | --- | --- | --- |
| 0 | Welcome and objectives | 2 | Set the tone: nobody is blamed for clicking. |
| 1 | Why this matters | 4 | Lead with a local incident if you have one. Far more powerful than a global statistic. |
| 2 | How phishing works | 4 | The five stages. Emphasise that stages 1–2 are invisible to the user, so judgement is the defence. |
| 3 | **Spot the red flags** | 10 | Hands-on. Do this projected and let people call out findings first. |
| 4 | Links and domains | 6 | The interactive URL. Ask the room where the real domain is *before* revealing it. |
| 5 | Fake websites | 3 | The padlock myth. Ask how many believed the padlock before you explain. |
| 6 | Social engineering tactics | 6 | Pick the four tactics most relevant to your organisation and go deep on those. |
| 7 | Beyond email | 3 | Relevant if your people are mobile-first. |
| 8 | Real-world cases | 4 | Ask what each organisation should have done differently. |
| 9 | **If you clicked** | 4 | Do not skip this. Most people have never read it before they need it. |
| 10 | Best practices | 3 | |
| 11 | Knowledge check | 3 | Six questions with explanations. |
| 12 | Final assessment | 3 | Ten questions, 80% to pass. |
| 13 | Cheat sheet | 2 | Print this and leave it on desks. |

### Delivering Section 3 (the exercises)

This is the heart of the session. There are four messages:

1. **IT password expiry** — an obvious fake, to build confidence and establish the baseline.
2. **A message from a genuine colleague** — every technical check passes, and it is still a trap. This is the one that lands hardest.
3. **A text message with a QR code** — the mobile-first attack.
4. **A genuine newsletter** — no red flags at all.

Work through them in order. Exercise 2 is the one worth spending time on, because
it breaks the habit people build in exercise 1 of "check the sender address and
I'm fine".

The score strips count what each person found. The **Reveal all** button shows
what they missed, which is often more instructive than what they found.

### Delivering Section 4 (the domain)

The interactive URL at the top of the section is colour-coded once rendered:

```
https://login.secure-verify.co/account/verify?session=8f2a91
```

Ask the room to identify the real destination domain before revealing the
colouring. Getting a group of people to call out a fake domain together is worth
more than any slide.

Then cover the four tricks: extra words, the `@` symbol, character swaps, and
homoglyphs from other alphabets. The Cyrillic examples are worth showing
projected — people are surprised that the address bar can look perfect and the
domain still be an attacker's.

## The important message to reinforce

Say this out loud, more than once:

> **Reporting a click early is never punished. That is the whole point of you
> being the last line of defence.**

Every breach in the case studies started with a person who reported late. If your
organisation punishes people for clicking, fix that before you deliver this
training — it removes your only remaining defence, because hidden mistakes cannot
be responded to.

## Assessment

- **Knowledge check** (section 11): 6 questions. Formative only, no pass mark.
- **Final assessment** (section 12): 10 questions, 80% to pass. Auto-marked, with
  an explanation for every answer, right or wrong. Unlimited retakes.
- A certificate appears at 80% or above. Participants type their name; it is held
  in their own browser and is never transmitted anywhere.

If you need an auditable record of completion, either capture a screenshot of the
certificate or have participants export it. The print stylesheet is set up to
produce a clean certificate page.

## Customising this module

It is one file, so editing is straightforward.

**Change the logo, brand colours and name** — find `--accent` in the `:root` block
at the top of the `<style>` section and set it to your brand colour. It drives
buttons, links and the progress bar.

**Add your own examples** — a fake message is a `.mailwrap` block. Copy an
existing one and replace the content. Mark the suspicious parts with
`class="hs"` and give each a `data-ok` and a `data-why`:

```html
<span class="hs" data-ok="1"
      data-why="<b>Why this is a red flag.</b> The explanation shown on click.">
  suspicious text
</span>
```

Set `data-ok="1"` for a genuine red flag. Set `data-ok="0"` for an element that
looks suspicious but is fine — these are the valuable ones, because they teach
people what *not* to flag. Both give feedback; only genuine flags score.

**Add quiz questions** — append an object to the array passed to
`buildQuiz` near the bottom of the file:

```javascript
{
  q: "The question text",
  a: ["first option", "second option", "third option"],
  correct: 1,           // index of the correct option
  why: "Explanation shown after answering, right or wrong."
}
```

**Remove a section** — delete the `<section class="panel" id="pN">` block and its
matching sidebar `<li>`. Navigation is index-based, so this stays consistent.

**Update the statistics** — section 8 cites publicly reported figures. Check the
current numbers in the latest
[FBI IC3 annual report](https://www.ic3.gov/),
[CISA guidance](https://www.cisa.gov/) and
[Verizon DBIR](https://www.verizon.com/business/resources/reports/dbir/),
and adjust the text. Attack volumes change; the tactics do not.

## Accessibility notes

- Fully keyboard navigable, including the message exercises. Every clickable
  element is focusable and responds to Enter and Space.
- A skip link is provided for keyboard users.
- Colour is never the only signal. Red flags are also explained in text, and the
  exercises are scored on interaction, not on appearance.
- Meets WCAG AA contrast on the body text and controls.
- Reflows to a single column on narrow screens and is legible on a phone.

## Content and sources

All example messages, companies and people are **fictional**. Nothing in the
module is designed to be a working phishing lure, and all domains shown are
reserved for documentation or examples.

Real incidents described in section 8 are from public reporting:

- **Colonial Pipeline (2021)** — remote access with a single reused password, no MFA.
- **Twitter (2020)** — phone-based social engineering against internal staff.
- **"Yes, And" campaign (2022)** — approximately 65,000 convincing fake profiles.
- **Business email compromise** — reported annual losses above $2 billion.

Before presenting, verify the current figures against the sources linked in the
module and above.

## Legal and ethical note

Only use this training on systems and networks you own or have written
authorisation to assess. The exercises teach recognition of attacks; they are not
for use against anyone else.

## Files

```
phishing-awareness-training/
├── index.html              The complete module. This is the whole deliverable.
├── README.md               This guide.
├── start.bat               Windows launcher
├── start.sh                macOS / Linux launcher
└── LICENSE                 MIT
```

## Licence

MIT — see `LICENSE`. Adapt and reuse freely for internal training.
