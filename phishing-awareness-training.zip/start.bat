@echo off
REM Opens the phishing awareness training module in your default browser.
REM
REM The module is a single self-contained HTML file and needs no internet
REM connection, no Python and no installation.

start "" "%~dp0index.html"
